import express from "express";
import multer from "multer";
import OpenAI from "openai";
import rateLimit from "express-rate-limit";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (["image/jpeg", "image/png", "image/webp", "image/gif"].includes(file.mimetype)) cb(null, true);
    else cb(new Error("Please upload a JPG, PNG, WebP, or GIF image."));
  }
});

app.use(express.static(__dirname));
app.use(express.json({ limit: "1mb" }));
app.use("/api/solve", rateLimit({ windowMs: 60 * 1000, limit: 10, standardHeaders: "draft-8", legacyHeaders: false }));

app.post("/api/solve", upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI is not configured yet. Add OPENAI_API_KEY to the server environment." });
    }

    const question = (req.body.question || "").trim();
    const language = (req.body.language || "English").slice(0, 40);
    const subject = (req.body.subject || "Auto detect").slice(0, 80);
    const style = (req.body.style || "Answer + explanation").slice(0, 80);

    if (!question && !req.file) {
      return res.status(400).json({ error: "Upload a question photo or type a question." });
    }

    const content = [{
      type: "input_text",
      text: `You are a friendly school study helper. Solve the student's question accurately and explain the reasoning clearly at an age-appropriate level. If the photo is blurry or the question is incomplete, say what you cannot read and ask for a clearer photo instead of guessing. Do not claim certainty when uncertain.
Preferred answer language: ${language}.
Subject: ${subject}.
Answer style: ${style}.
Question text (if supplied): ${question || "(Question is in the attached image.)"}`
    }];

    if (req.file) {
      const mime = req.file.mimetype;
      const base64 = req.file.buffer.toString("base64");
      content.push({
        type: "input_image",
        image_url: `data:${mime};base64,${base64}`,
        detail: "high"
      });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: [{ role: "user", content }],
      max_output_tokens: 1200
    });

    res.json({ answer: response.output_text || "I couldn't produce an answer. Please try again with a clearer question." });
  } catch (error) {
    console.error("Solve request failed:", error?.message || error);
    if (error instanceof multer.MulterError && error.code === "LIMIT_FILE_SIZE") {
      return res.status(413).json({ error: "Image is too large. Please use an image under 5 MB." });
    }
    res.status(500).json({ error: "Sorry, the question could not be solved right now. Check the server setup and try again." });
  }
});

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Invalid upload." });
});

app.listen(port, () => console.log(`Question Solver running on http://localhost:${port}`));
